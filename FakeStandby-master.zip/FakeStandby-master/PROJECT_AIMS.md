# Project aims

## What users should receive

The projects goal is to provide a simple, easy to use, minimal and performant Android application to save battery life.
This is done by coding a material desgin android app. The app has consistent design and and the project logo as its icon.
Store information and website content must also fit to the branding of the project.

## Code standards

The code for this project is as minimal as possible.
It is modular, scalable and documented as well as following code formatting standards.
