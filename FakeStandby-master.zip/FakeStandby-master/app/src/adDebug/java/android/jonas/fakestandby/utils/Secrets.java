package android.jonas.fakestandby.utils;

public class Secrets {

    public static class Ads {
        public static String BANNER_ID = "ca-app-pub-3940256099942544/6300978111";
    }

}
