package android.jonas.fakestandby.utils;

public interface OverlayCancelListener {
    void onCancel();
}
