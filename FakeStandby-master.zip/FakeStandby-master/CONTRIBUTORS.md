# Contributors

> I want to thank all contributors that help to develop this app!

## Code contributors

> Code contributions are the most powerful change at a projects heart.
> Those require very precise and good work. Thanks to all code contributors!

 
* [dependabot[bot]](https://github.com/apps/dependabot) (5 contributions)  
* [Gitoffthelawn](https://github.com/Gitoffthelawn) (3 contributions)  
* [Poussinou](https://github.com/Poussinou) (1 contribution) 

## POEditor (Translation)

> Special thanks also goes to the great people helping with the translations!
> The app is now already translated into 26 languages!

 
* 18439301296  
* 200308  
* 2352406Mk  
* 774  
* Adam  
* aevw  
* Agung krisdayanto  
* Agungkris  
* Alejandro  
* Alexandr  
* Ali  
* Ali  
* Alice  
* anas  
* Anon  
* Antonio Silva  
* Atiq kaled  
* Ban ban  
* Bayu  
* bill  
* Cetinibrahim  
* Coke  
* Cor Menger  
* cykgle  
* Danieldesouzamelo07  
* DarkGagan  
* Diego flores   
* dour  
* Edu  
* Elessar Trancos  
* Elizabeth Aburto  
* Emir can  
* Fahad  
* Felixcrat  
* Freefeel  
* Gabriel  
* Giulio  
* h  
* h_1  
* Hakimjon  
* Hans-Guenther Kost  
* Henrique  
* Info  
* Ioji Barrett  
* Ivars   
* jimmy  
* jk  
* Juan  
* Juan Vargas  
* Kaan Kutan  
* Kakaraka  
* Katherine  
* Kristijan Krezic  
* L  
* Lau  
* Lqwh2h2cwa  
* Lucassuperti  
* MAAHIL566  
* Maciej  
* Maciej   
* marlon  
* Martina Thakur  
* Max Burkardt  
* mecqor  
* MingYu  
* mode  
* Mrkotofey  
* Muddy  
* musics  
* Mustafa hossain  
* nate  
* NNT909  
* odkate  
* Pascal  
* Pelian  
* poi  
* Pratik Mullick  
* Qiuyingjie  
* r  
* Randi Setiawan  
* Redouane  
* Riccardo Bettoli  
* Rinat  
* Ruben Marquez   
* Ryan  
* Salih  
* sans  
* sardonicdozen  
* Sergei  
* SILVIO  
* su  
* Sumit Prasad  
* SuperKubaGaming56  
* SuppaMan  
* tenoredigrazia  
* tGd  
* Tom  
* Tom  
* tybercylez  
* Tyson Silva  
* undra thomas  
* Vahidboush  
* wainortyho  
* xiaowei  
* Yang Hongyi  
* Youssef   
* zhanghm  
* zuoxp  
* Zurich Rose  
* zwis  
* Валерий Ермолаев  
* Джесіка  
* Игорь Петрович Гуменников  
* Мирон  
* Михаил  
* محمد  
* 张思桐  
* 染色体X_Y  
* 江兆陽  
* 满满  
* 煌上煌  
* 王在祥  
* 王无极  
* 瑞杰  
* 电音爱好者  
* 祺杰呀  
* 荔枝  
* 蒙昌明  
* 郑硕  
* 陈上杰 